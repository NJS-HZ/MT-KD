# Necessary Imports
import os
import torch
import torchvision
import tarfile
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd

from datasets import cic2017
from utils import *
from models import *
from metrics import *
from unlearning import *

torch.manual_seed(100)
train_ds, valid_ds = cic2017()

batch_size = 256
train_dl = DataLoader(train_ds, batch_size, shuffle=True, num_workers=0)
valid_dl = DataLoader(valid_ds, batch_size, num_workers=0)
num_classes = 10
classwise_train = {}
for i in range(num_classes):
    classwise_train[i] = []

for img, label in train_ds:
    classwise_train[label].append((img, label))

classwise_test = {}
for i in range(num_classes):
    classwise_test[i] = []

for img, label in valid_ds:
    classwise_test[label].append((img, label))

device = 'cuda'
model = AllCNN().to(device = device)

epochs = 25
max_lr = 0.01
grad_clip = 0.1
weight_decay = 1e-4
opt_func = torch.optim.Adam

history = fit_one_cycle(epochs, max_lr, model, train_dl, valid_dl,
                             grad_clip=grad_clip,
                             weight_decay=weight_decay,
                             opt_func=opt_func, device = device)
torch.save(model.state_dict(), "AllCNN_cic2017_ALL_CLASSES.pt")

torch.save(model.state_dict(), "AllCNN_cic2017_ALL_CLASSES.pt")

model.load_state_dict(torch.load("AllCNN_cic2017_ALL_CLASSES.pt"))
history = [evaluate(model, valid_dl, device = device)]
history


# defining the noise structure
class Noise(nn.Module):
    def __init__(self, *dim):
        super().__init__()
        self.noise = torch.nn.Parameter(torch.randn(*dim), requires_grad=True)

    def forward(self):
        return self.noise

# list of all classes
classes = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# classes which are required to un-learn
classes_to_forget = [4,5]

# classwise list of samples
num_classes = 10
classwise_train = {}
for i in range(num_classes):
    classwise_train[i] = []

for img, label in train_ds:
    classwise_train[label].append((img, label))

classwise_test = {}
for i in range(num_classes):
    classwise_test[i] = []

for img, label in valid_ds:
    classwise_test[label].append((img, label))

# getting some samples from retain classes
num_samples_per_class = 1000

retain_samples = []
for i in range(len(classes)):
    if classes[i] not in classes_to_forget:
        retain_samples += classwise_train[i][:num_samples_per_class]

# retain validation set
retain_valid = []
for cls in range(num_classes):
    if cls not in classes_to_forget:
        for img, label in classwise_test[cls]:
            retain_valid.append((img, label))

# forget validation set
forget_valid = []
for cls in range(num_classes):
    if cls in classes_to_forget:
        for img, label in classwise_test[cls]:
            forget_valid.append((img, label))

forget_valid_dl = DataLoader(forget_valid, batch_size, num_workers=3, pin_memory=True)
retain_valid_dl = DataLoader(retain_valid, batch_size * 2, num_workers=3, pin_memory=True)

before_forget_acc = []
before_retain_acc = []

print("Performance of Standard Forget Model on Forget Class (Before adding noise)")
history = [evaluate(model, forget_valid_dl)]
before_forget_acc.append(history[0]["Acc"] * 100)
print("Accuracy: {}".format(history[0]["Acc"] * 100))
print("Loss: {}".format(history[0]["Loss"]))

print("Performance of Standard Forget Model on Retain Class (Before adding noise)")
history = [evaluate(model, retain_valid_dl)]
before_retain_acc.append(history[0]["Acc"] * 100)
print("Accuracy: {}".format(history[0]["Acc"] * 100))
print("Loss: {}".format(history[0]["Loss"]))

from sklearn.metrics import confusion_matrix
import seaborn as sns
# 获取加入噪声前的预测结果和真实标签
all_preds, all_labels = [], []
model.eval()
with torch.no_grad():
    for data in forget_valid_dl:
        inputs, labels = data
        inputs, labels = inputs.to(device), labels.to(device)
        outputs, *_ = model(inputs)  # 提取 logits
        _, preds = torch.max(outputs, 1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())
    for data in retain_valid_dl:
        inputs, labels = data
        inputs, labels = inputs.to(device), labels.to(device)
        outputs, *_ = model(inputs)  # 提取 logits
        _, preds = torch.max(outputs, 1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.cpu().numpy())

# 绘制整体混淆矩阵
def plot_confusion_matrix(y_true, y_pred, classes, title='unlearning 4classes Confusion Matrix'):
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 10))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, yticklabels=classes)
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.title(title)
    os.makedirs('results', exist_ok=True)  # 确保目录存在
    plt.savefig(os.path.join('results', title.replace(" ", "_") + '遗忘四组混淆矩阵.png'))
    plt.show()

# 绘制整体混淆矩阵
plot_confusion_matrix(all_labels, all_preds, list(range(num_classes)))

# loading the model
model = AllCNN().to(device = device)
model.load_state_dict(torch.load("AllCNN_cic2017_ALL_CLASSES.pt"))

noises = {}
for cls in classes_to_forget:
    print("Optiming loss for class {}".format(cls))
    noises[cls] = Noise(batch_size, 1, 28, 28).cuda()  # 生成噪声样本
    opt = torch.optim.Adam(noises[cls].parameters(), lr = 0.1)

    num_epochs = 5
    num_steps = 8
    class_label = cls
    for epoch in range(num_epochs):
        total_loss = []
        for batch in range(num_steps):
            inputs = noises[cls]()  # 生成噪声样本
            # 随机生成错误标签（从保留类中随机选择）
            retain_classes = [c for c in range(num_classes) if c not in classes_to_forget]
            wrong_labels = torch.tensor(np.random.choice(retain_classes, batch_size)).cuda()
            
            outputs, *_ = model(inputs)  # 提取模型的 logits
            # 修改损失函数：最大化错误分类
            loss = F.cross_entropy(outputs, wrong_labels.long()) + 0.1 * torch.mean(torch.sum(torch.square(inputs), [1, 2, 3]))  # 计算损失
            opt.zero_grad()  # 清除梯度
            loss.backward()  # 反向传播
            opt.step()  # 更新参数
            total_loss.append(loss.cpu().detach().numpy())  # 记录损失
        print("Loss: {}".format(np.mean(total_loss)))  # 输出平均损失



batch_size = 256
noisy_data = []
num_batches = 20
class_num = 0

# 创建带有噪声数据的列表
for cls in classes_to_forget:
    for i in range(num_batches):
        batch = noises[cls]().cpu().detach()  # 获取批量噪声样本
        for i in range(batch[0].size(0)):
            noisy_data.append((batch[i], torch.tensor(class_num)))  # 添加噪声样本及标签

other_samples = []
# 将保留样本也添加到 noisy_data 中
for i in range(len(retain_samples)):
    other_samples.append((retain_samples[i][0].cpu(), torch.tensor(retain_samples[i][1])))
noisy_data += other_samples

# 创建数据加载器
noisy_loader = torch.utils.data.DataLoader(noisy_data, batch_size=256, shuffle=True)

optimizer = torch.optim.Adam(model.parameters(), lr=0.02)

# 训练循环
for epoch in range(1):
    model.train(True)
    running_loss = 0.0
    running_acc = 0
    for i, data in enumerate(noisy_loader):
        inputs, labels = data
        inputs, labels = inputs.cuda(), torch.tensor(labels).cuda()

        optimizer.zero_grad()

        # 获取模型输出并确保输出是 logits
        outputs, *_ = model(inputs)  # 如果 model 返回元组，只提取 logits
        loss = F.cross_entropy(outputs, labels.long())  # 计算交叉熵损失

        loss.backward()  # 反向传播
        optimizer.step()  # 更新权重

        # 统计损失和准确率
        running_loss += loss.item() * inputs.size(0)
        out = torch.argmax(outputs.detach(), dim=1)
        assert out.shape == labels.shape
        running_acc += (labels == out).sum().item()

    print(f"Train loss {epoch+1}: {running_loss/len(train_ds)}, Train Acc: {running_acc*100/len(train_ds)}%")
torch.save(model.state_dict(), "model_teacher1.pt")


print("Performance of Standard Forget Model on Forget Class")
history = [evaluate(model, forget_valid_dl)]
print("Accuracy: {}".format(history[0]["Acc"]*100))
print("Loss: {}".format(history[0]["Loss"]))

print("Performance of Standard Forget Model on Retain Class")
history = [evaluate(model, retain_valid_dl)]
print("Accuracy: {}".format(history[0]["Acc"]*100))
print("Loss: {}".format(history[0]["Loss"]))

# 使用原始模型初始化teacher_model_2
model.load_state_dict(torch.load("AllCNN_cic2017_ALL_CLASSES.pt"))

# 创建包含所有数据的DataLoader
all_data = retain_samples + forget_valid
all_loader = torch.utils.data.DataLoader(all_data, batch_size=256, shuffle=True)

optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)

# 训练循环
for epoch in range(10):  # 增加训练轮数
    model.train(True)
    running_loss = 0.0
    running_acc = 0
    
    for i, data in enumerate(all_loader):
        inputs, labels = data
        inputs, labels = inputs.cuda(), torch.tensor(labels).cuda()

        optimizer.zero_grad()
        outputs, *_ = model(inputs)
        
        # 使用交叉熵损失
        loss = F.cross_entropy(outputs, labels.long())
        
        # 添加L2正则化
        l2_lambda = 0.0001
        l2_norm = sum(p.pow(2.0).sum() for p in model.parameters())
        loss = loss + l2_lambda * l2_norm

        loss.backward()
        optimizer.step()

        # 统计损失和准确率
        running_loss += loss.item() * inputs.size(0)
        out = torch.argmax(outputs.detach(), dim=1)
        running_acc += (labels == out).sum().item()

    scheduler.step()
    
    # 每个epoch结束后评估
    model.eval()
    val_results = evaluate(model, valid_dl)
    print(f"Epoch {epoch+1}, Train Loss: {running_loss/len(all_loader.dataset)}, Train Acc: {running_acc*100/len(all_loader.dataset)}%, Val Acc: {val_results['Acc']}%")

torch.save(model.state_dict(), "model_teacher2.pt")

from torch.optim.lr_scheduler import StepLR  # 导入 StepLR
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# 加载第一段代码生成的模型作为教师模型
teacher_model_1 = AllCNN(n_channels=1).to(device)
teacher_model_1.load_state_dict(torch.load("model_teacher1.pt"))

# 加载第二段代码生成的模型作为教师模型
teacher_model_2 = AllCNN(n_channels=1).to(device)
teacher_model_2.load_state_dict(torch.load("model_teacher2.pt"))

# 初始化学生模型
student_model = AllCNN(n_channels=1).to(device)  # 确保学生模型与教师模型架构一致

# 初始化优化器和学习率调度器
optimizer = torch.optim.Adam(student_model.parameters(), lr=0.001)
scheduler = StepLR(optimizer, step_size=30, gamma=0.1)  # 每 30 个 epoch 学习率降低为原来的 0.1 倍

# 训练学生模型
for epoch in range(20):  # 可调整 epoch 数量
    student_model.train()
    running_loss = 0.0
    running_acc = 0
    for i, (inputs, labels) in enumerate(forget_valid_dl):  # 这里使用 forget_valid_dl 进行训练
        inputs, labels = inputs.to(device), labels.to(device)

        optimizer.zero_grad()
        student_outputs, *_ = student_model(inputs)
        teacher_outputs_1, *_ = teacher_model_1(inputs)  # 第一个教师模型的输出
        teacher_outputs_2, *_ = teacher_model_2(inputs)  # 第二个教师模型的输出

        # 加权结合两个教师模型的输出
        w1 = 0.3  # teacher_model_1 的权重
        w2 = 0.7  # teacher_model_2 的权重
        teacher_outputs = w1 * teacher_outputs_1 + w2 * teacher_outputs_2

        # 调整损失函数权重
        alpha = 0.8  # 交叉熵损失的权重
        beta = 0.2  # KL 散度损失的权重
        loss = alpha * F.cross_entropy(student_outputs, labels.long()) + \
               beta * torch.nn.functional.kl_div(
                   torch.log_softmax(student_outputs, dim=1),
                   torch.softmax(teacher_outputs, dim=1),
                   reduction='batchmean'
               )

        loss.backward()
        optimizer.step()

        running_loss += loss.item() * inputs.size(0)
        preds = torch.argmax(student_outputs, dim=1)
        running_acc += (preds == labels).sum().item()

    scheduler.step()  # 调用学习率调度器
    epoch_loss = running_loss / len(forget_valid_dl.dataset)
    epoch_acc = running_acc * 100 / len(forget_valid_dl.dataset)
    print(f"Epoch {epoch+1}, Loss: {epoch_loss}, Acc: {epoch_acc}%")


from torch.optim.lr_scheduler import StepLR  # 导入 StepLR
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# 加载第一段代码生成的模型作为教师模型
teacher_model_1 = AllCNN(n_channels=1).to(device)
teacher_model_1.load_state_dict(torch.load("model_teacher1.pt"))

# 加载第二段代码生成的模型作为教师模型
teacher_model_2 = AllCNN(n_channels=1).to(device)
teacher_model_2.load_state_dict(torch.load("model_teacher2.pt"))

# 初始化学生模型
student_model = AllCNN(n_channels=1).to(device)  # 确保学生模型与教师模型架构一致

# 检查数据分布
from collections import Counter

# 检查 forget_valid_dl 的标签分布
forget_labels = []
for _, labels in forget_valid_dl:
    forget_labels.extend(labels.tolist())
print("Forget Class Label Distribution:", Counter(forget_labels))

# 检查 retain_valid_dl 的标签分布
retain_labels = []
for _, labels in retain_valid_dl:
    retain_labels.extend(labels.tolist())
print("Retain Class Label Distribution:", Counter(retain_labels))

# 初始化优化器和学习率调度器
optimizer = torch.optim.Adam(student_model.parameters(), lr=0.001)
scheduler = StepLR(optimizer, step_size=30, gamma=0.1)  # 每 30 个 epoch 学习率降低为原来的 0.1 倍

# 合并 forget_valid_dl 和 retain_valid_dl 的数据
combined_data = forget_valid_dl.dataset + retain_valid_dl.dataset
combined_dl = torch.utils.data.DataLoader(combined_data, batch_size=256, shuffle=True)

# 训练学生模型
for epoch in range(20):  # 可调整 epoch 数量
    student_model.train()
    running_loss = 0.0
    running_acc = 0
    for i, (inputs, labels) in enumerate(combined_dl):  # 使用 combined_dl 进行训练
        inputs, labels = inputs.to(device), labels.to(device)

        optimizer.zero_grad()
        student_outputs, *_ = student_model(inputs)
        teacher_outputs_1, *_ = teacher_model_1(inputs)  # 第一个教师模型的输出
        teacher_outputs_2, *_ = teacher_model_2(inputs)  # 第二个教师模型的输出

        # 加权结合两个教师模型的输出
        w1 = 0.3  # teacher_model_1 的权重
        w2 = 0.7  # teacher_model_2 的权重
        teacher_outputs = w1 * teacher_outputs_1 + w2 * teacher_outputs_2

        # 调整损失函数权重
        alpha = 0.9  # 增加交叉熵损失的权重
        beta = 0.1   # 降低 KL 散度损失的权重
        loss = alpha * F.cross_entropy(student_outputs, labels.long()) + \
               beta * torch.nn.functional.kl_div(
                   torch.log_softmax(student_outputs, dim=1),
                   torch.softmax(teacher_outputs, dim=1),
                   reduction='batchmean'
               )

        loss.backward()
        optimizer.step()

        running_loss += loss.item() * inputs.size(0)
        preds = torch.argmax(student_outputs, dim=1)
        running_acc += (preds == labels).sum().item()

    scheduler.step()  # 调用学习率调度器
    epoch_loss = running_loss / len(combined_dl.dataset)
    epoch_acc = running_acc * 100 / len(combined_dl.dataset)
    print(f"Epoch {epoch+1}, Loss: {epoch_loss}, Acc: {epoch_acc}%")

# 训练结束后评估模型
def evaluate(model, dataloader):
    model.eval()  # 设置模型为评估模式
    running_loss = 0.0
    running_acc = 0
    all_preds = []
    all_labels = []
    with torch.no_grad():  # 禁用梯度计算
        for inputs, labels in dataloader:
            inputs, labels = inputs.to(device), labels.to(device)
            outputs, *_ = model(inputs)
            loss = F.cross_entropy(outputs, labels.long())
            running_loss += loss.item() * inputs.size(0)
            preds = torch.argmax(outputs, dim=1)
            running_acc += (preds == labels).sum().item()
            all_preds.extend(preds.cpu().numpy())  # 收集预测结果
            all_labels.extend(labels.cpu().numpy())  # 收集真实标签
    loss = running_loss / len(dataloader.dataset)
    acc = 100 * running_acc / len(dataloader.dataset)
    return {
        "Loss": loss,
        "Acc": acc,
        "preds": all_preds,
        "labels": all_labels
    }

# 评估整体数据集的准确率
print("Performance on Combined Dataset:")
history_combined = evaluate(student_model, combined_dl)
print(f"Combined Dataset - Loss: {history_combined['Loss']}, Acc: {history_combined['Acc']}%")

# 绘制混淆矩阵
def plot_confusion_matrix(labels, preds, class_names, title="Confusion Matrix"):
    cm = confusion_matrix(labels, preds)
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=class_names, yticklabels=class_names)
    plt.xlabel("Predicted")
    plt.ylabel("True")
    plt.title(title)
    plt.show()

# 类别名称（根据数据集调整）
class_names = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]

# 绘制整体数据集的混淆矩阵
print("Confusion Matrix for Combined Dataset:")
plot_confusion_matrix(history_combined["labels"], history_combined["preds"], class_names, title="Combined Dataset Confusion Matrix")
